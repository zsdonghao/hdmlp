from setuptools import setup, find_packages
setup(
    name = "hdmlp",
    version = "1.1",
    # packages = find_packages(),
    packages = ['hdmlp'],
    description='HDL. support regression',
    include_package_data=True,
    author='haodong',
    author_email='hao.dong11@imperial.ac.uk',
    url = "https://zsdonghao.github.io" ,
    license = "Confidential" ,
    # scripts=['script/ha']
    scripts=['test.py', 'test_load_model.py'],
    # description = "This is an Confidential package",
    keywords = "deep learning",
    platform=['any'],
)
# from distutils.core import setup
# setup(name='hdmlp',
#       version='1.0',
#       py_modules=['hdmlp'],
#       )
