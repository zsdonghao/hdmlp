#! /usr/bin/python
# -*- coding: utf8 -*-

"""
# *******************************************************
#  * Copyright (C) 2016 Hao Dong <hao.dong11@imperial.ac.uk>
#  *
#  * The code is a part of HDL project
#  *
#  * The code can not be copied, distributed, modified and/or
#  * used for research and/or any commercial use without the
#  * express permission of Hao Dong
#  *
# *******************************************************/
"""

from hdmlp.mlp import *


def main_classification():
    ## load MNIST data
    print("Loading data...")
    X_train, y_train, X_val, y_val, X_test, y_test =  load_dataset() ##
    print('X_train.shape', X_train.shape)  # (50000, 1, 28, 28)
    print('y_train.shape', y_train.shape)  # (50000,)
    print('X_val.shape', X_val.shape)      # (10000, 1, 28, 28)
    print('y_val.shape', y_val.shape)      # (10000,)
    print('X_test.shape', X_test.shape)    # (10000, 1, 28, 28)
    print('y_test.shape',  y_test.shape)    # (10000,)

    inputs = T.tensor4('inputs')     #  4-dimensional ndarray
    targets = T.ivector('targets')   #  1-dimension int32 ndarray classification

    ## you can use it for classification or regression
    mlpc = MLP(
            inputs=inputs,
            targets=targets,
            n_units=[800, 800, 10],
            shape=(None, 1, 28, 28),
            drop=[0.2, 0.5, 0.5],
            activation=lasagne.nonlinearities.rectify,
            activation_out=lasagne.nonlinearities.softmax,
            )

    ## print all params and structure
    mlpc.get_all_params_info()

    ## pre-train    (unsupervised, greedy layer-wise)
    # mlpc.start_pretrain(
    #         X_train=X_train,
    #         X_val=X_val,
    #         shape=(-1, 1, 28, 28),
    #         l1_a=[4, 4],
    #         rho=[0.15, 0.15],
    #         l2_w=[0.004, 0.004],
    #         n_epochs_pre = [200, 200],
    #         batch_size_pre = [100, 100],
    #         update = 'adam',
    #         learning_rate = 0.0001,
    #         print_freq = 10,
    #         )

    ## train    (supervised, fine-tune)
    mlpc.start_training(
            X_train=X_train,
            y_train=y_train,
            X_val=X_val,
            y_val=y_val,
            n_epochs=200,
            batch_size=500,
            learning_rate=0.0001,
            update='adam',
            loss_type='ce',       # classification
            pi_neuron=[0, 0, 0],  # pi_col
            pi_feature=[0, 0, 0], # pi_row
            l1_w=[0.000, 0.000, 0.000],
            l2_w=[0.000, 0.000, 0.000],
            l1_a=[0, 0],
            print_freq=10,
            )

    ## evaluate the network by using test data
    print("\nEvaluation")
    predict_fn = mlpc.get_predict_function()
    ## if classification, you will got a one-hot-format
    y_predict = predict_fn(X_test)
    y_predict= np.argmax(y_predict, axis=1)
    evaluation(y_test, y_predict, 10)

    ##
    print("\nAll properties")
    attrs = vars(mlpc)
    print(', '.join("%s: %s\n" % item for item in attrs.items()))

    ##
    print('\nSave model as < model_hdmlp.mat > ...')
    import scipy
    from scipy.io import savemat, loadmat
    params = mlpc.get_all_params()
    params_dict = {}
    for i in range(len(params)):
        params_dict[str(params[i])+str(i//2+1)] = params[i].get_value()
    savemat('model_hdmlp.mat', params_dict)

    ##
    # Optionally, you could now dump the network weights to a file like this:
    print('Save model as < model_hdmlp.npz > ...')
    np.savez('model_hdmlp.npz', *lasagne.layers.get_all_param_values(mlpc.network))
    ##
    # And load them again later on like this: 见 mnist_use.py
    # with np.load('model_hdmlp.npz') as f:
    #     param_values = [f['arr_%d' % i] for i in range(len(f.files))]
    # lasagne.layers.set_all_param_values(network, param_values)


def main_regression():
    ## load MNIST data
    print("Loading data...")
    X_train, y_train, X_val, y_val, X_test, y_test =  load_dataset() ##
    print('X_train.shape', X_train.shape)  # (50000, 1, 28, 28)
    print('y_train.shape', y_train.shape)  # (50000,)
    print('X_val.shape', X_val.shape)      # (10000, 1, 28, 28)
    print('y_val.shape', y_val.shape)      # (10000,)
    print('X_test.shape', X_test.shape)    # (10000, 1, 28, 28)
    print('y_test.shape',  y_test.shape)    # (10000,)

    inputs = T.tensor4('inputs')     #  4-dimensional ndarray
    # targets = T.ivector('targets')   #  1-dimension int32 ndarray classification
    targets = T.fvector('targets')

    ## you can use it for classification or regression
    mlpc = MLP(
            inputs=inputs,
            targets=targets,
            # n_units=[200, 200, 10],   # classification
            n_units=[200, 200, 1],      # regression
            shape=(None, 1, 28, 28),
            drop=[0.2, 0.45, 0.5],
            activation=lasagne.nonlinearities.sigmoid,
            activation_out=lasagne.nonlinearities.sigmoid,
            )

    ## print all params and structure
    mlpc.get_all_params_info()

    ## pre-train    (unsupervised, greedy layer-wise)
    # mlpc.start_pretrain(
    #         X_train=X_train,
    #         X_val=X_val,
    #         shape=(-1, 1, 28, 28),
    #         l1_a=[4, 4],
    #         rho=[0.15, 0.15],
    #         l2_w=[0.004, 0.004],
    #         n_epochs_pre = [200, 200],
    #         batch_size_pre = [100, 100],
    #         update = 'adam',
    #         learning_rate = 0.0001,
    #         print_freq = 10,
    #         )

    ## train    (supervised, fine-tune)
    mlpc.start_training(
            X_train=X_train,
            y_train=y_train,
            X_val=X_val,
            y_val=y_val,
            n_epochs=500,
            batch_size=500,
            learning_rate=0.0001,
            update='adam',
            loss_type='mse',    # regression
            pi_neuron=[0, 0, 0],  # pi_col
            pi_feature=[0, 0, 0], # pi_row
            l1_w=[0.000, 0.000, 0.000],
            l2_w=[0.000, 0.000, 0.000],
            l1_a=[0, 0],
            print_freq=10,
            )

    ## evaluate the network by using test data
    print("\nEvaluation")
    predict_fn = mlpc.get_predict_function()
    ## if classification, you will got a one-hot-format
    y_predict = predict_fn(X_test)
    y_predict= np.argmax(y_predict, axis=1)
    evaluation(y_test, y_predict, 10)

    ##
    print("\nAll properties")
    attrs = vars(mlpc)
    print(', '.join("%s: %s\n" % item for item in attrs.items()))

    ##
    print('\nSave model as < model_hdmlp.mat > ...')
    import scipy
    from scipy.io import savemat, loadmat
    params = mlpc.get_all_params()
    params_dict = {}
    for i in range(len(params)):
        params_dict[str(params[i])+str(i//2+1)] = params[i].get_value()
    savemat('model_hdmlp.mat', params_dict)

    ##
    # Optionally, you could now dump the network weights to a file like this:
    print('Saving model as < model_hdmlp.npz > ...')
    np.savez('model_hdmlp.npz', *lasagne.layers.get_all_param_values(mlpc.network))
    ##
    # And load them again later on like this: 见 mnist_use.py
    # with np.load('model_hdmlp.npz') as f:
    #     param_values = [f['arr_%d' % i] for i in range(len(f.files))]
    # lasagne.layers.set_all_param_values(network, param_values)

if __name__ == '__main__':
    main_classification()
    # main_regression()
