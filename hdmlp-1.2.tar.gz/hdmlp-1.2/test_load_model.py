#! /usr/bin/python
# -*- coding: utf8 -*-

"""
# *******************************************************
#  * Copyright (C) 2016 Hao Dong <hao.dong11@imperial.ac.uk>
#  *
#  * The code is a part of HDL project
#  *
#  * The code can not be copied, distributed, modified and/or
#  * used for research and/or any commercial use without the
#  * express permission of Hao Dong
#  *
# *******************************************************/
"""

from hdmlp.mlp import *


def main_load_classification():
    ## load MNIST data
    print("Loading data...")
    X_train, y_train, X_val, y_val, X_test, y_test =  load_dataset() ##
    print('X_train.shape', X_train.shape)  # (50000, 1, 28, 28)
    print('y_train.shape', y_train.shape)  # (50000,)
    print('X_val.shape', X_val.shape)      # (10000, 1, 28, 28)
    print('y_val.shape', y_val.shape)      # (10000,)
    print('X_test.shape', X_test.shape)    # (10000, 1, 28, 28)
    print('y_test.shape',  y_test.shape)    # (10000,)

    inputs = T.tensor4('inputs')     #  4-dimensional ndarray
    targets = T.ivector('targets')   #  1-dimension int32 ndarray classification

    ## you can use it for classification or regression
    mlpc = MLP(
            inputs=inputs,
            targets=targets,
            n_units=[800, 800, 10],
            shape=(None, 1, 28, 28),
            drop=[0.01, 0, 0],
            activation=lasagne.nonlinearities.rectify,
            activation_out=lasagne.nonlinearities.softmax,
            )

    ## print all params and structure
    mlpc.get_all_params_info()

    ## load a model to the network
    with np.load('model_hdmlp.npz') as f:
        param_values = [f['arr_%d' % i] for i in range(len(f.files))]

    ## you may want to drop some connection of 1st hidden layer to see how accuracy decrease
    p = 0.0 # probability of 0
    dropconnect_mask = np.random.binomial(n=1, p=1-p, size=param_values[0].shape)
    param_values[0] = (param_values[0] * dropconnect_mask).astype(dtype=np.float32)

    ## set model params
    lasagne.layers.set_all_param_values(mlpc.network, param_values)

    ## evaluate the network by using test data
    print("\nEvaluation")
    ## disable dropout by setting deterministic to True
    # predict_fn = mlpc.get_predict_function(deterministic=True)
    ## you may want to drop some neuron of 1st hidden layer to see how accuracy decrease
    predict_fn = mlpc.get_predict_function(deterministic=False)

    ## if classification, you will got a one-hot-format
    y_predict = predict_fn(X_test)
    y_predict= np.argmax(y_predict, axis=1)
    evaluation(y_test, y_predict, 10)

    ##
    print("\nAll properties")
    attrs = vars(mlpc)
    print(', '.join("%s: %s\n" % item for item in attrs.items()))




if __name__ == '__main__':
    main_load_classification()
